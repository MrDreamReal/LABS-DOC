
CySA+ IR Actor Identification — Sample Datasets (for Splunk)

FILES
-----
Incident A (Script Kiddie scanning/brute force):
  - incidentA_apache_access.log   (sourcetype suggestion: apache:access)

Incident B (Cybercriminal: phish -> Cobalt Strike -> ransomware + exfil):
  - incidentB_sysmon.ndjson       (sourcetype: XmlWinEventLog:Microsoft-Windows-Sysmon/Operational)
  - incidentB_email_gateway.csv   (sourcetype: o365:message)

Incident C (Insider: after-hours + USB exfil):
  - incidentC_security.csv        (sourcetype: WinEventLog:Security)
  - incidentC_sysmon.ndjson       (sourcetype: XmlWinEventLog:Microsoft-Windows-Sysmon/Operational)

Incident D (Nation-state/APT: targeted spear-phish + long dwell C2):
  - incidentD_sysmon.ndjson       (sourcetype: XmlWinEventLog:Microsoft-Windows-Sysmon/Operational)
  - incidentD_zeek_http.tsv       (sourcetype: zeek:http)
  - incidentD_zeek_ssl.tsv        (sourcetype: zeek:ssl)

INDEX
-----
Create an index named: ir_lab
Upload all files and assign them to index=ir_lab with the suggested sourcetypes above.

TIME
----
All _time values are 2025-10-21 .. 2025-10-28 UTC in the files.
Splunk should auto-parse Apache time. For CSV/NDJSON/TSV, ensure the _time field is used or rely on Splunk parsing if recognized.

HOW TO INGEST
-------------
1) Splunk Web > Settings > Add Data > Upload > select each file.
2) Set Source Type:
   - incidentA_apache_access.log : apache:access (or create if missing; CLF combined format).
   - *sysmon.ndjson              : XmlWinEventLog:Microsoft-Windows-Sysmon/Operational (line-per-event JSON).
   - incidentC_security.csv      : WinEventLog:Security (CSV with EventCode, Account_Name etc.).
   - incidentD_zeek_http.tsv     : zeek:http (tab-separated, headers included).
   - incidentD_zeek_ssl.tsv      : zeek:ssl (tab-separated, headers included).
   - incidentB_email_gateway.csv : o365:message (CSV).

3) Set Host field = file or keep default; Index = ir_lab.

SPL QUICK START
---------------
Use the queries provided in the "hands-on" exercise message to explore the data.
Example sanity checks:

- Apache scanner hits:
  index=ir_lab sourcetype="apache:access" | stats count by user_agent

- Sysmon events count by case host:
  index=ir_lab sourcetype="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" | stats count by host, EventCode

- Zeek rare SNI:
  index=ir_lab sourcetype=zeek:ssl | stats count by server_name

NOTES
-----
- These are synthetic datasets for training purposes.
- Feel free to extend with your own fields/IQCs to match your environment.
